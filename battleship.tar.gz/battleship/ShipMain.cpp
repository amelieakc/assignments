// Main.cpp
//Battleship

#include <iostream>
#include "PointCollection.h"
#include "Point.h"
#include "Ship.h"
#include "Board.h"
using namespace std;

int main() {

  Board B;

  B.display();


  return 0;
}
